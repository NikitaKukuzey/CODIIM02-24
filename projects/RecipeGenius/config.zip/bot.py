import logging

from aiogram import Bot, Dispatcher

from config.config import TOKEN
from handlers.user import router


async def main() -> None:
    bot = Bot(token=TOKEN, parse_mode="HTML")
    dp = Dispatcher()

    logging.basicConfig(level=logging.INFO,
                        filemode='a',
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    dp.include_routers(router)

    await dp.start_polling(bot)
