import cv2
import torch


def prepare_image(path):
    image = cv2.imread(path).transpose((2, 0, 1))
    image = torch.from_numpy(image).float()

    return image
