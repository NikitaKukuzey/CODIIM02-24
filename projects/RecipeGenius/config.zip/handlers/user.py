import os

from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import Message

from giga_chat import gigachat
from model.predictor import MyModel
from utils.messages import *

menu = {'apple_pie': 'яблочный пирог',
        'caesar_salad': 'салат "Цезарь"', 'caprese_salad': 'салат "Капрезе"',
        'carrot_cake': 'морковный пирог', 'cheesecake': 'чизкейк',
        'chicken_curry': 'куриное карри', 'chocolate_cake': 'шоколадный пирог',
        'chocolate_mousse': 'шоколадный мусс', 'donuts': 'пончики',
        'dumplings': 'пельмени', 'eggs_benedict': 'яичница по-бенедиктински',
        'greek_salad': 'греческий салат', 'lasagna': 'лазанья',
        'pancakes': 'блины', 'panna_cotta': 'панна котта',
        'peking_duck': 'утка по-пекински', 'pizza': 'пицца',
        'ramen': 'рамен', 'risotto': 'ризотто',
        'waffles': 'вафли'}

router = Router()
model = MyModel("model/model.joblib")


@router.message(Command(commands=["help", "start"]))
async def helping_handler(message: Message):
    await message.reply(start)

@router.message(Command(commands=["stop"]))
async def helping_handler(message: Message):
    if message.from_user.username == "MihahamYT":
        exit()


@router.message(F.photo)
async def photo_hadler(message: Message, bot: Bot):
    print("Collected")
    global model
    images = message.photo

    if images is None:
        await message.reply("Это не фото")
        return 0

    path = f"{message.from_user.id}.jpeg"

    file_info = await bot.get_file(message.photo[-1].file_id)
    downloaded_file = await bot.download_file(file_info.file_path)
    src = file_info.file_path.replace(f'photos/', '')
    with open(src, 'wb') as new_file:
        new_file.write(downloaded_file.getvalue())
    print("we downloaded file")
    prediction = model(src)


    await message.reply(pred.format(menu[prediction] + "\n" + gigachat(prediction)))
